# __init__.py

# Version of the VocabularyDownloader package
__version__ = "0.0.1"