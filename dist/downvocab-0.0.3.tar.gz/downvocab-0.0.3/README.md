# downvocab  
  
This small tool is to aid all English learners to download the pronouncation sound track in mp3.  
## How to download

`pip3 install downvocab`

## How to use  

downvocab accept two input methods.

**CSV**

`downvocab -c <csv_file_path> -o <output_directory>`

**Singal Word**
  
`downvocab -d <vocabulary> -o <output_directory>`

